import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Problem2 = () => {
    const [modalAOpen, setModalAOpen] = useState(false);
    const [modalBOpen, setModalBOpen] = useState(false);
    const [modalCOpen, setModalCOpen] = useState(false);
    const [onlyEven, setOnlyEven] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [contacts, setContacts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(false);
  
    // Function to fetch contacts from the API
    const fetchContacts = async () => {
      setLoading(true);
      try {
        const response = await axios.get(
          `https://contact.mediusware.com/api/contacts?page=${currentPage}`
        );
        setContacts((prevContacts) => [...prevContacts, ...response.data]);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching contacts: ', error);
        setLoading(false);
      }
    };
  
    // Function to filter contacts based on even IDs and search query
    const filteredContacts = contacts
      .filter((contact) => (!onlyEven || contact.id % 2 === 0))
      .filter((contact) =>
        contact.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
  
    // Function to handle opening and closing modals
    const openModalA = () => {
      setModalAOpen(true);
      setModalBOpen(false);
      setModalCOpen(false);
      setCurrentPage(1);
      fetchContacts();
    };
  
    const openModalB = () => {
      setModalAOpen(false);
      setModalBOpen(true);
      setModalCOpen(false);
      setCurrentPage(1);
      fetchContacts();
    };
  
    const openModalC = () => {
      setModalAOpen(false);
      setModalBOpen(false);
      setModalCOpen(true);
    };
  
    const closeModal = () => {
      setModalAOpen(false);
      setModalBOpen(false);
      setModalCOpen(false);
    };
  
    // Function to handle infinite scrolling
    const handleScroll = () => {
      if (
        window.innerHeight + document.documentElement.scrollTop ===
        document.documentElement.offsetHeight
      ) {
        setCurrentPage((prevPage) => prevPage + 1);
      }
    };
  
    useEffect(() => {
      if (currentPage > 1) {
        fetchContacts();
      }
      window.addEventListener('scroll', handleScroll);
      return () => {
        window.removeEventListener('scroll', handleScroll);
      };
    }, [currentPage]);

   return (
    <div>
      <div>
        <button style={{ backgroundColor: '#46139f' }} onClick={openModalA}>
          All Contact
        </button>
        <button style={{ backgroundColor: '#ff7f50' }} onClick={openModalB}>
          US Contact
        </button>
      </div>
      {modalAOpen && (
        <div>
          <button
            style={{ backgroundColor: '#46139f' }}
            onClick={openModalA}
          >
            Modal Button A
          </button>
          <button
            style={{ backgroundColor: '#ff7f50' }}
            onClick={openModalB}
          >
            Modal Button B
          </button>
          <button onClick={closeModal}>Modal Button C</button>
          <div>
            <label>
              Only even
              <input
                type="checkbox"
                checked={onlyEven}
                onChange={() => setOnlyEven(!onlyEven)}
              />
            </label>
          </div>
          <input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <div>
            {filteredContacts.map((contact) => (
              <div key={contact.id} onClick={openModalC}>
                {contact.name}
              </div>
            ))}
            {loading && <p>Loading...</p>}
          </div>
        </div>
      )}
      {modalBOpen && (
        <div>
          {/* Similar structure as Modal A */}
        </div>
      )}
      {modalCOpen && (
        <div>
          {/* Modal C content */}
          <button onClick={closeModal}>Modal Button C</button>
        </div>
      )}
    </div>
  );
};

export default Problem2;